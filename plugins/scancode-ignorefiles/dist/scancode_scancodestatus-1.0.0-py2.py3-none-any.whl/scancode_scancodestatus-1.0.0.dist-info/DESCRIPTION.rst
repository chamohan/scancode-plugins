A lib to scan the json file and return the status


